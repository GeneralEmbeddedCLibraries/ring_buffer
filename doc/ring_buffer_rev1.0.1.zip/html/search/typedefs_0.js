var searchData=
[
  ['p_5fring_5fbuffer_5ft_56',['p_ring_buffer_t',['../group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga0c8502122580371763eb136a93d14e49',1,'ring_buffer.h']]]
];
