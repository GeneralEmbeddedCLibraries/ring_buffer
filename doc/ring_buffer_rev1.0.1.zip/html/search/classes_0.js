var searchData=
[
  ['ring_5fbuffer_5fdata_5ft_33',['ring_buffer_data_t',['../unionring__buffer__data__t.html',1,'']]],
  ['ring_5fbuffer_5fs_34',['ring_buffer_s',['../structring__buffer__s.html',1,'']]]
];
