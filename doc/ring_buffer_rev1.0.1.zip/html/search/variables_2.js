var searchData=
[
  ['p_5fdata_53',['p_data',['../structring__buffer__s.html#a9c4547a9a9ca67bd1f88b96a39e6dd10',1,'ring_buffer_s']]]
];
