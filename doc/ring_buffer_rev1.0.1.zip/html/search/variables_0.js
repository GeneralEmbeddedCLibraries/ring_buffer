var searchData=
[
  ['f_49',['f',['../unionring__buffer__data__t.html#a95db6878413681d15d3c5da4a0a3f2f8',1,'ring_buffer_data_t']]]
];
