var group___r_i_n_g___b_u_f_f_e_r =
[
    [ "ring_buffer_data_t", "unionring__buffer__data__t.html", [
      [ "f", "unionring__buffer__data__t.html#a95db6878413681d15d3c5da4a0a3f2f8", null ],
      [ "i32", "unionring__buffer__data__t.html#a83a2a902bf575aafce5b4fd7e3bde2d0", null ],
      [ "u32", "unionring__buffer__data__t.html#a1df94b6130e07cd5df345a3d86d0ce60", null ]
    ] ],
    [ "ring_buffer_s", "structring__buffer__s.html", [
      [ "idx", "structring__buffer__s.html#a8ebf3724aa44270039d7896f299a44b1", null ],
      [ "is_init", "structring__buffer__s.html#a98f35d1fa9630bdf41638208bfe03fd8", null ],
      [ "p_data", "structring__buffer__s.html#a9c4547a9a9ca67bd1f88b96a39e6dd10", null ],
      [ "size", "structring__buffer__s.html#ab8579a79c8b64087fff1a6c3b59a38f9", null ]
    ] ],
    [ "ring_buffer_t", "group___r_i_n_g___b_u_f_f_e_r.html#ga91a1a666451e8fa4779788baec57691f", null ],
    [ "ring_buffer_check_index", "group___r_i_n_g___b_u_f_f_e_r.html#ga40eac621bc1a8045588bffa9de68108d", null ],
    [ "ring_buffer_increment_index", "group___r_i_n_g___b_u_f_f_e_r.html#ga40d9f03a8a78d891d0afe0b0d1ecfe02", null ],
    [ "ring_buffer_parse_index", "group___r_i_n_g___b_u_f_f_e_r.html#gaec80b8efa0af3ca6cd8d389e8853db61", null ],
    [ "ring_buffer_wrap_index", "group___r_i_n_g___b_u_f_f_e_r.html#ga27dc707555ffca386e49e043376d5b81", null ]
];