var annotated_dup =
[
    [ "ring_buffer_data_t", "unionring__buffer__data__t.html", "unionring__buffer__data__t" ],
    [ "ring_buffer_s", "structring__buffer__s.html", "structring__buffer__s" ]
];