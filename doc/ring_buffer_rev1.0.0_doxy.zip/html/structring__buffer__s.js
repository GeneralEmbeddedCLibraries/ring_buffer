var structring__buffer__s =
[
    [ "idx", "structring__buffer__s.html#a8ebf3724aa44270039d7896f299a44b1", null ],
    [ "p_data", "structring__buffer__s.html#a9c4547a9a9ca67bd1f88b96a39e6dd10", null ],
    [ "size", "structring__buffer__s.html#ab8579a79c8b64087fff1a6c3b59a38f9", null ]
];