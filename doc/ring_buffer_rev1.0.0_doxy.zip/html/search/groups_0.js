var searchData=
[
  ['ring_5fbuffer_54',['RING_BUFFER',['../group___r_i_n_g___b_u_f_f_e_r.html',1,'']]],
  ['ring_5fbuffer_5fapi_55',['RING_BUFFER_API',['../group___r_i_n_g___b_u_f_f_e_r___a_p_i.html',1,'']]]
];
