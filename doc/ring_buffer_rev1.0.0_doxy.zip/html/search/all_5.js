var searchData=
[
  ['size_26',['size',['../structring__buffer__s.html#ab8579a79c8b64087fff1a6c3b59a38f9',1,'ring_buffer_s']]]
];
