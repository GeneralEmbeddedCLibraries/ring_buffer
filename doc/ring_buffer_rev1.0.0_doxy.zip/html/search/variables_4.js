var searchData=
[
  ['u32_48',['u32',['../unionring__buffer__data__t.html#a1df94b6130e07cd5df345a3d86d0ce60',1,'ring_buffer_data_t']]]
];
