var searchData=
[
  ['ering_5fbuffer_5ferror_0',['eRING_BUFFER_ERROR',['../group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gga7019e83b501a2d5ae4c228280a97da81a03d7e6ef55edf1f2a1bb6b1c41552bbd',1,'ring_buffer.h']]],
  ['ering_5fbuffer_5fok_1',['eRING_BUFFER_OK',['../group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gga7019e83b501a2d5ae4c228280a97da81ace6430e9c30b42b9d901028207fb004e',1,'ring_buffer.h']]]
];
