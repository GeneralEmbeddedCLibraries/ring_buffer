var searchData=
[
  ['ring_5fbuffer_5fstatus_5ft_51',['ring_buffer_status_t',['../group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga7019e83b501a2d5ae4c228280a97da81',1,'ring_buffer.h']]]
];
