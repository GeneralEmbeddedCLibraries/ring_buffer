var searchData=
[
  ['i32_3',['i32',['../unionring__buffer__data__t.html#a83a2a902bf575aafce5b4fd7e3bde2d0',1,'ring_buffer_data_t']]],
  ['idx_4',['idx',['../structring__buffer__s.html#a8ebf3724aa44270039d7896f299a44b1',1,'ring_buffer_s']]]
];
