var group___r_i_n_g___b_u_f_f_e_r___a_p_i =
[
    [ "p_ring_buffer_t", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga0c8502122580371763eb136a93d14e49", null ],
    [ "ring_buffer_status_t", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga7019e83b501a2d5ae4c228280a97da81", [
      [ "eRING_BUFFER_OK", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gga7019e83b501a2d5ae4c228280a97da81ace6430e9c30b42b9d901028207fb004e", null ],
      [ "eRING_BUFFER_ERROR", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gga7019e83b501a2d5ae4c228280a97da81a03d7e6ef55edf1f2a1bb6b1c41552bbd", null ]
    ] ],
    [ "ring_buffer_add_f", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga6eca3eca768ca12220f37e645d69f969", null ],
    [ "ring_buffer_add_i32", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga0aa2c5bf462d70863e47125f718d23da", null ],
    [ "ring_buffer_add_u32", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gac49bc22e06c92c1e046edd6ce9889663", null ],
    [ "ring_buffer_get_f", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga774309168f10a6a9cb87f269be0c308b", null ],
    [ "ring_buffer_get_i32", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga3b050ecb5482ae2ba0732ab2ad00a9ee", null ],
    [ "ring_buffer_get_u32", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gad7d285ee2043d8bfad6bc8cc4ddb990c", null ],
    [ "ring_buffer_init", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga766668cf45e3211aa6d0b98f103334d1", null ]
];