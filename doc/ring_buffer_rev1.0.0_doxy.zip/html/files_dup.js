var files_dup =
[
    [ "ring_buffer.c", "ring__buffer_8c.html", "ring__buffer_8c" ],
    [ "ring_buffer.h", "ring__buffer_8h.html", "ring__buffer_8h" ]
];