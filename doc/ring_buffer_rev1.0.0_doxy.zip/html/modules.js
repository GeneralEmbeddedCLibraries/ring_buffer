var modules =
[
    [ "RING_BUFFER", "group___r_i_n_g___b_u_f_f_e_r.html", "group___r_i_n_g___b_u_f_f_e_r" ],
    [ "RING_BUFFER_API", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html", "group___r_i_n_g___b_u_f_f_e_r___a_p_i" ]
];