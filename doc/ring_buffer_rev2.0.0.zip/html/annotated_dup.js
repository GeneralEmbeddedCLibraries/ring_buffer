var annotated_dup =
[
    [ "ring_buffer_attr_t", "structring__buffer__attr__t.html", "structring__buffer__attr__t" ],
    [ "ring_buffer_s", "structring__buffer__s.html", "structring__buffer__s" ]
];