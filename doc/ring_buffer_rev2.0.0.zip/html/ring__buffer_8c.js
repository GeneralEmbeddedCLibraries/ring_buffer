var ring__buffer_8c =
[
    [ "ring_buffer_t", "group___r_i_n_g___b_u_f_f_e_r.html#ga91a1a666451e8fa4779788baec57691f", null ],
    [ "ring_buffer_add", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga66657b3b270deb5f3bfd96bce5d46911", null ],
    [ "ring_buffer_check_index", "group___r_i_n_g___b_u_f_f_e_r.html#ga40eac621bc1a8045588bffa9de68108d", null ],
    [ "ring_buffer_clear_mem", "group___r_i_n_g___b_u_f_f_e_r.html#ga1330b6eda3a0e841375cbf6a022a2225", null ],
    [ "ring_buffer_custom_setup", "group___r_i_n_g___b_u_f_f_e_r.html#ga8072c5c21cab8f99b65505a410d2aa51", null ],
    [ "ring_buffer_decrement_index", "group___r_i_n_g___b_u_f_f_e_r.html#ga0b0993b6bb3b35dc29f57d02e3921319", null ],
    [ "ring_buffer_default_setup", "group___r_i_n_g___b_u_f_f_e_r.html#gae5bd99550c176c7b9148c2039aacccd3", null ],
    [ "ring_buffer_get", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga6fb63960631a8f1150c8519eef535d70", null ],
    [ "ring_buffer_get_by_index", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga995d70bbbd2f530f6da3f60880176870", null ],
    [ "ring_buffer_get_free", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gab41a9ea5e0fff7c3aa8f8f658b3f7640", null ],
    [ "ring_buffer_get_item_size", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gaa9ce8d63f4293df3a07f4e27b5632877", null ],
    [ "ring_buffer_get_name", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gafb446c1b040a1f7ffe8deb798cfb8044", null ],
    [ "ring_buffer_get_size", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga664725533d589ad59e3b2270a71c5f26", null ],
    [ "ring_buffer_get_taken", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gaeab0c8f392c2bf31216c60ab67d55898", null ],
    [ "ring_buffer_increment_index", "group___r_i_n_g___b_u_f_f_e_r.html#ga40d9f03a8a78d891d0afe0b0d1ecfe02", null ],
    [ "ring_buffer_init", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga1a785f716ca36dd01c4f9b04daad10bd", null ],
    [ "ring_buffer_is_init", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gabcc0d98df71fc2a7ead30661bf39b482", null ],
    [ "ring_buffer_parse_index", "group___r_i_n_g___b_u_f_f_e_r.html#gaec80b8efa0af3ca6cd8d389e8853db61", null ],
    [ "ring_buffer_reset", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gad2bb499af9f0e575c4e31b3a21ccf76a", null ],
    [ "ring_buffer_wrap_index", "group___r_i_n_g___b_u_f_f_e_r.html#ga27dc707555ffca386e49e043376d5b81", null ]
];