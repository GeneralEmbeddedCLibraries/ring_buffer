var structring__buffer__attr__t =
[
    [ "item_size", "structring__buffer__attr__t.html#aa4091725358a73de1c439c1aa053b810", null ],
    [ "name", "structring__buffer__attr__t.html#a45bc18f1b80c2ec52cd59940d114dc58", null ],
    [ "override", "structring__buffer__attr__t.html#a1dc9ce30a3e15ee9c329e335a1fd26c1", null ],
    [ "p_mem", "structring__buffer__attr__t.html#ad2f29b855cd9d1f19c0c7d0f5ab1f29d", null ]
];