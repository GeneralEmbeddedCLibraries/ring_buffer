var group___r_i_n_g___b_u_f_f_e_r___a_p_i =
[
    [ "ring_buffer_attr_t", "structring__buffer__attr__t.html", [
      [ "item_size", "structring__buffer__attr__t.html#aa4091725358a73de1c439c1aa053b810", null ],
      [ "name", "structring__buffer__attr__t.html#a45bc18f1b80c2ec52cd59940d114dc58", null ],
      [ "override", "structring__buffer__attr__t.html#a1dc9ce30a3e15ee9c329e335a1fd26c1", null ],
      [ "p_mem", "structring__buffer__attr__t.html#ad2f29b855cd9d1f19c0c7d0f5ab1f29d", null ]
    ] ],
    [ "RING_BUFFER_VER_DEVELOP", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gafe33da74b38effd29be43cd2186b84f1", null ],
    [ "RING_BUFFER_VER_MAJOR", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gaca5b28a1f5db08c38266229e18414faf", null ],
    [ "RING_BUFFER_VER_MINOR", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga2244d1f1790548010540ca7c4ee2adc2", null ],
    [ "float32_t", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga4611b605e45ab401f02cab15c5e38715", null ],
    [ "p_ring_buffer_t", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga0c8502122580371763eb136a93d14e49", null ],
    [ "ring_buffer_status_t", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga7019e83b501a2d5ae4c228280a97da81", [
      [ "eRING_BUFFER_OK", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gga7019e83b501a2d5ae4c228280a97da81ace6430e9c30b42b9d901028207fb004e", null ],
      [ "eRING_BUFFER_ERROR", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gga7019e83b501a2d5ae4c228280a97da81a03d7e6ef55edf1f2a1bb6b1c41552bbd", null ],
      [ "eRING_BUFFER_ERROR_INIT", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gga7019e83b501a2d5ae4c228280a97da81abd228d0598e47bdb046a9f977f5ecd0a", null ],
      [ "eRING_BUFFER_ERROR_MEM", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gga7019e83b501a2d5ae4c228280a97da81ae534de42cb3f5b4136a90b879478881e", null ],
      [ "eRING_BUFFER_ERROR_INST", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gga7019e83b501a2d5ae4c228280a97da81a7204c0175ce4b83fea41d95e6363dadf", null ],
      [ "eRING_BUFFER_FULL", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gga7019e83b501a2d5ae4c228280a97da81aa81e1fc7d362b338b0bfe6cd64c608e6", null ],
      [ "eRING_BUFFER_EMPTY", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gga7019e83b501a2d5ae4c228280a97da81a5fe4928194095f11ebe57515dccdf1bd", null ]
    ] ],
    [ "ring_buffer_add", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga66657b3b270deb5f3bfd96bce5d46911", null ],
    [ "ring_buffer_get", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga6fb63960631a8f1150c8519eef535d70", null ],
    [ "ring_buffer_get_by_index", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga995d70bbbd2f530f6da3f60880176870", null ],
    [ "ring_buffer_get_free", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gab41a9ea5e0fff7c3aa8f8f658b3f7640", null ],
    [ "ring_buffer_get_item_size", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gaa9ce8d63f4293df3a07f4e27b5632877", null ],
    [ "ring_buffer_get_name", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gafb446c1b040a1f7ffe8deb798cfb8044", null ],
    [ "ring_buffer_get_size", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga664725533d589ad59e3b2270a71c5f26", null ],
    [ "ring_buffer_get_taken", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gaeab0c8f392c2bf31216c60ab67d55898", null ],
    [ "ring_buffer_init", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga1a785f716ca36dd01c4f9b04daad10bd", null ],
    [ "ring_buffer_is_init", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gabcc0d98df71fc2a7ead30661bf39b482", null ],
    [ "ring_buffer_reset", "group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#gad2bb499af9f0e575c4e31b3a21ccf76a", null ]
];