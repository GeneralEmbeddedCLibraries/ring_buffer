var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "ring_buffer.c", "ring__buffer_8c.html", "ring__buffer_8c" ],
    [ "ring_buffer.h", "ring__buffer_8h.html", "ring__buffer_8h" ]
];