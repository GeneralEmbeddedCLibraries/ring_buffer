var group___r_i_n_g___b_u_f_f_e_r =
[
    [ "ring_buffer_s", "structring__buffer__s.html", [
      [ "head", "structring__buffer__s.html#a4c99449f5d9cd9133ea3bbe8ed50513d", null ],
      [ "is_empty", "structring__buffer__s.html#a9a3dd97b0834d165bb00f169294c3707", null ],
      [ "is_full", "structring__buffer__s.html#a5a60db0637b36a9b36f5c3adb2e65b21", null ],
      [ "is_init", "structring__buffer__s.html#a98f35d1fa9630bdf41638208bfe03fd8", null ],
      [ "name", "structring__buffer__s.html#a9a3f0aca8c4765eb65f284a379269644", null ],
      [ "override", "structring__buffer__s.html#a520b858990c778b620e1bc4bd55c5493", null ],
      [ "p_data", "structring__buffer__s.html#a4d9f29475ebbbef35f701b3ac5550ca4", null ],
      [ "size_of_buffer", "structring__buffer__s.html#ac8b7d529a6c43886544b44eec1de25d5", null ],
      [ "size_of_item", "structring__buffer__s.html#ae546598ac4f6228d6f3331cf366e7525", null ],
      [ "tail", "structring__buffer__s.html#ad22e580f727c7041a316e791e147c8cf", null ]
    ] ],
    [ "ring_buffer_t", "group___r_i_n_g___b_u_f_f_e_r.html#ga91a1a666451e8fa4779788baec57691f", null ],
    [ "ring_buffer_check_index", "group___r_i_n_g___b_u_f_f_e_r.html#ga40eac621bc1a8045588bffa9de68108d", null ],
    [ "ring_buffer_clear_mem", "group___r_i_n_g___b_u_f_f_e_r.html#ga1330b6eda3a0e841375cbf6a022a2225", null ],
    [ "ring_buffer_custom_setup", "group___r_i_n_g___b_u_f_f_e_r.html#ga8072c5c21cab8f99b65505a410d2aa51", null ],
    [ "ring_buffer_decrement_index", "group___r_i_n_g___b_u_f_f_e_r.html#ga0b0993b6bb3b35dc29f57d02e3921319", null ],
    [ "ring_buffer_default_setup", "group___r_i_n_g___b_u_f_f_e_r.html#gae5bd99550c176c7b9148c2039aacccd3", null ],
    [ "ring_buffer_increment_index", "group___r_i_n_g___b_u_f_f_e_r.html#ga40d9f03a8a78d891d0afe0b0d1ecfe02", null ],
    [ "ring_buffer_parse_index", "group___r_i_n_g___b_u_f_f_e_r.html#gaec80b8efa0af3ca6cd8d389e8853db61", null ],
    [ "ring_buffer_wrap_index", "group___r_i_n_g___b_u_f_f_e_r.html#ga27dc707555ffca386e49e043376d5b81", null ]
];