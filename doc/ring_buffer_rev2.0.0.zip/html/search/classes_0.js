var searchData=
[
  ['ring_5fbuffer_5fattr_5ft_51',['ring_buffer_attr_t',['../structring__buffer__attr__t.html',1,'']]],
  ['ring_5fbuffer_5fs_52',['ring_buffer_s',['../structring__buffer__s.html',1,'']]]
];
