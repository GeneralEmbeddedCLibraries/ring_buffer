var searchData=
[
  ['head_8',['head',['../structring__buffer__s.html#a4c99449f5d9cd9133ea3bbe8ed50513d',1,'ring_buffer_s']]]
];
