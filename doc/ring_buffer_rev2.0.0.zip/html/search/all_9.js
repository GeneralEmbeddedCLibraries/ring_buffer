var searchData=
[
  ['tail_50',['tail',['../structring__buffer__s.html#ad22e580f727c7041a316e791e147c8cf',1,'ring_buffer_s']]]
];
