var searchData=
[
  ['p_5fdata_15',['p_data',['../structring__buffer__s.html#a4d9f29475ebbbef35f701b3ac5550ca4',1,'ring_buffer_s']]],
  ['p_5fmem_16',['p_mem',['../structring__buffer__attr__t.html#ad2f29b855cd9d1f19c0c7d0f5ab1f29d',1,'ring_buffer_attr_t']]],
  ['p_5fring_5fbuffer_5ft_17',['p_ring_buffer_t',['../group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga0c8502122580371763eb136a93d14e49',1,'ring_buffer.h']]]
];
