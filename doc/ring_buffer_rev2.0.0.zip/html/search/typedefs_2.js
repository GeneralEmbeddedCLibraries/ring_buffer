var searchData=
[
  ['ring_5fbuffer_5ft_88',['ring_buffer_t',['../group___r_i_n_g___b_u_f_f_e_r.html#ga91a1a666451e8fa4779788baec57691f',1,'ring_buffer.c']]]
];
