var searchData=
[
  ['name_79',['name',['../structring__buffer__s.html#a9a3f0aca8c4765eb65f284a379269644',1,'ring_buffer_s::name()'],['../structring__buffer__attr__t.html#a45bc18f1b80c2ec52cd59940d114dc58',1,'ring_buffer_attr_t::name()']]]
];
