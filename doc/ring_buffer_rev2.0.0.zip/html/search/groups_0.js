var searchData=
[
  ['ring_5fbuffer_97',['RING_BUFFER',['../group___r_i_n_g___b_u_f_f_e_r.html',1,'']]],
  ['ring_5fbuffer_5fapi_98',['RING_BUFFER_API',['../group___r_i_n_g___b_u_f_f_e_r___a_p_i.html',1,'']]]
];
