var searchData=
[
  ['p_5fdata_81',['p_data',['../structring__buffer__s.html#a4d9f29475ebbbef35f701b3ac5550ca4',1,'ring_buffer_s']]],
  ['p_5fmem_82',['p_mem',['../structring__buffer__attr__t.html#ad2f29b855cd9d1f19c0c7d0f5ab1f29d',1,'ring_buffer_attr_t']]]
];
