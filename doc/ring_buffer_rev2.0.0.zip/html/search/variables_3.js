var searchData=
[
  ['override_80',['override',['../structring__buffer__s.html#a520b858990c778b620e1bc4bd55c5493',1,'ring_buffer_s::override()'],['../structring__buffer__attr__t.html#a1dc9ce30a3e15ee9c329e335a1fd26c1',1,'ring_buffer_attr_t::override()']]]
];
