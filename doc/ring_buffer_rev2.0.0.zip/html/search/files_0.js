var searchData=
[
  ['ring_5fbuffer_2ec_53',['ring_buffer.c',['../ring__buffer_8c.html',1,'']]],
  ['ring_5fbuffer_2eh_54',['ring_buffer.h',['../ring__buffer_8h.html',1,'']]]
];
