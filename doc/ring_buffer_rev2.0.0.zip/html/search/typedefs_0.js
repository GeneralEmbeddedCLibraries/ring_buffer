var searchData=
[
  ['float32_5ft_86',['float32_t',['../group___r_i_n_g___b_u_f_f_e_r___a_p_i.html#ga4611b605e45ab401f02cab15c5e38715',1,'ring_buffer.h']]]
];
