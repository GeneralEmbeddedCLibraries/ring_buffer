var searchData=
[
  ['size_5fof_5fbuffer_83',['size_of_buffer',['../structring__buffer__s.html#ac8b7d529a6c43886544b44eec1de25d5',1,'ring_buffer_s']]],
  ['size_5fof_5fitem_84',['size_of_item',['../structring__buffer__s.html#ae546598ac4f6228d6f3331cf366e7525',1,'ring_buffer_s']]]
];
